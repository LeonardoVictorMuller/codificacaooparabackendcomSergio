num = int(input("digite um numero: "))
num2 = int(input("digite outro numero: "))

if(num > num2 ):
    print(num," é maior que ", num2)
else:
    print(num2," é maior que ", num)
if(num == num2):
    print("os numeros sao iguais")
