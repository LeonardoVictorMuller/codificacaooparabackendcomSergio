def converter(valor):
    return (valor*1.8 + 32)
graus = float(input("Digite a temperatura em graus Celsius: "))
print(converter(graus))