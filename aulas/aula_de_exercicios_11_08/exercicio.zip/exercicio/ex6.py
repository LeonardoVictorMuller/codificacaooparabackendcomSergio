num = int(input("digite um numero: "))
i = num - 1
while(num > i):
    print(i)
    i -= 1
    if(i == 0):
        break
