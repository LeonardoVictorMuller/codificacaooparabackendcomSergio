num = int(input("digite um numero: "))
if(num % 2 == 0 ):
    print("numero é par")
else:
    print("numero é impar")