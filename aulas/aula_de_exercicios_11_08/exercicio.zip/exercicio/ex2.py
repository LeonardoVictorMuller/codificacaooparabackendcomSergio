n = float(input("Digite um numero: "))
n2 = float(input("Digite outro numero: "))

print("A soma dos numeors é ", (n + n2))