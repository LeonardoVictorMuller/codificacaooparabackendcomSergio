num = int(input("digite um numero: "))
for i in range(1, 10):
    print(num, " x ", i, " = ", num * i)
    i += 1